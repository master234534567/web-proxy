const express = require("express");
const http = require("http");
const path = require("path");
const cors = require("cors");
const { createServer } = require("wisp-server-node");
const Ultraviolet = require("@titaniumnetwork-dev/ultraviolet");

const app = express();
const server = http.createServer(app);

const PORT = process.env.PORT || 3000;

// Wisp WebSocket server for UV transport
const wispServer = createServer({ logLevel: "NONE" });

server.on("upgrade", (req, socket, head) => {
  if (req.url.startsWith("/wisp/")) {
    wispServer.handleUpgrade(req, socket, head);
  } else {
    socket.destroy();
  }
});

app.use(cors());
app.use(express.static(path.join(__dirname, "../public")));

// Serve Ultraviolet static files
const uvPath = path.dirname(require.resolve("@titaniumnetwork-dev/ultraviolet"));
app.use("/uv/", express.static(uvPath));

// Serve epoxy transport
try {
  const epoxyPath = path.dirname(require.resolve("@mercuryworkshop/epoxy-transport"));
  app.use("/epoxy/", express.static(epoxyPath));
} catch (e) {
  console.log("Epoxy not found, skipping...");
}

// UV config endpoint
app.get("/uv/uv.config.js", (req, res) => {
  res.setHeader("Content-Type", "application/javascript");
  res.send(`
self.__uv$config = {
  prefix: '/uv/service/',
  encodeUrl: Ultraviolet.codec.xor.encode,
  decodeUrl: Ultraviolet.codec.xor.decode,
  handler: '/uv/uv.handler.js',
  bundle: '/uv/uv.bundle.js',
  config: '/uv/uv.config.js',
  sw: '/uv/uv.sw.js',
};
  `.trim());
});

// Catch-all for SPA routing
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

server.listen(PORT, () => {
  console.log(`🚀 Nebula Proxy running on port ${PORT}`);
});
