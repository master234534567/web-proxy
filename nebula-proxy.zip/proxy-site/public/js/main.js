// ─── STARS CANVAS ────────────────────────────────────────
const canvas = document.getElementById("stars");
const ctx = canvas.getContext("2d");
let stars = [];

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

function initStars() {
  stars = Array.from({ length: 120 }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 1.2 + 0.2,
    alpha: Math.random(),
    speed: Math.random() * 0.004 + 0.001,
    phase: Math.random() * Math.PI * 2,
  }));
}

function drawStars() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const t = Date.now() / 1000;
  stars.forEach((s) => {
    const a = 0.3 + 0.5 * Math.sin(t * s.speed * 60 + s.phase);
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(200, 210, 255, ${a})`;
    ctx.fill();
  });
  requestAnimationFrame(drawStars);
}

resizeCanvas();
initStars();
drawStars();
window.addEventListener("resize", () => { resizeCanvas(); initStars(); });

// ─── TAB NAVIGATION ──────────────────────────────────────
const navLinks = document.querySelectorAll(".nav-link");
const tabs = document.querySelectorAll(".tab-content");

navLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const tab = link.dataset.tab;
    navLinks.forEach((l) => l.classList.remove("active"));
    tabs.forEach((t) => t.classList.remove("active"));
    link.classList.add("active");
    document.getElementById(`tab-${tab}`)?.classList.add("active");
  });
});

// ─── PROXY LOGIC ─────────────────────────────────────────
const overlay = document.getElementById("proxy-overlay");
const frame = document.getElementById("proxy-frame");
const urlDisplay = document.getElementById("proxy-url-display");

function encodeUrl(raw) {
  let url = raw.trim();
  // If it looks like a URL, navigate; otherwise do a Google search
  const isUrl =
    url.startsWith("http://") ||
    url.startsWith("https://") ||
    /^[\w-]+\.[a-z]{2,}/.test(url);

  if (!isUrl) {
    url = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
  } else if (!url.startsWith("http")) {
    url = `https://${url}`;
  }

  if (window.__uv$config) {
    return __uv$config.prefix + __uv$config.encodeUrl(url);
  }
  return url;
}

function openProxy(rawUrl) {
  const encoded = encodeUrl(rawUrl);
  frame.src = encoded;
  urlDisplay.textContent = rawUrl;
  overlay.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeProxy() {
  overlay.classList.add("hidden");
  frame.src = "about:blank";
  document.body.style.overflow = "";
}

// Search bar
document.getElementById("go-btn").addEventListener("click", () => {
  const val = document.getElementById("proxy-input").value;
  if (val) openProxy(val);
});
document.getElementById("proxy-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const val = e.target.value;
    if (val) openProxy(val);
  }
});

// Proxy bar controls
document.getElementById("proxy-close").addEventListener("click", closeProxy);
document.getElementById("proxy-back").addEventListener("click", () => frame.contentWindow?.history.back());
document.getElementById("proxy-forward").addEventListener("click", () => frame.contentWindow?.history.forward());
document.getElementById("proxy-reload").addEventListener("click", () => { frame.src = frame.src; });

// Quick links
document.querySelectorAll(".quick-btn").forEach((btn) => {
  btn.addEventListener("click", () => openProxy(btn.dataset.url));
});

// Game cards
document.querySelectorAll(".game-card").forEach((card) => {
  card.addEventListener("click", () => openProxy(card.dataset.url));
});

// App cards
document.querySelectorAll(".app-card").forEach((card) => {
  card.addEventListener("click", () => openProxy(card.dataset.url));
});

// Search hints
document.querySelectorAll(".hint").forEach((hint) => {
  hint.addEventListener("click", () => {
    const text = hint.textContent.replace("Try: ", "");
    document.getElementById("proxy-input").value = text;
    openProxy(text);
  });
});

// ─── SETTINGS ────────────────────────────────────────────
// Tab cloak
document.getElementById("apply-cloak").addEventListener("click", () => {
  const title = document.getElementById("cloak-title").value;
  const icon = document.getElementById("cloak-icon").value;
  if (title) document.title = title;
  if (icon) {
    let link = document.querySelector("link[rel~='icon']");
    if (!link) { link = document.createElement("link"); link.rel = "icon"; document.head.appendChild(link); }
    link.href = icon.startsWith("http") ? icon : `data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>${icon}</text></svg>`;
  }
  localStorage.setItem("cloak-title", title);
  localStorage.setItem("cloak-icon", icon);
});

// Panic key
let panicKey = localStorage.getItem("panic-key") || "Escape";
let panicUrl = localStorage.getItem("panic-url") || "https://classroom.google.com";

if (localStorage.getItem("panic-key")) {
  document.getElementById("panic-key").value = panicKey;
}
if (localStorage.getItem("panic-url")) {
  document.getElementById("panic-url").value = panicUrl;
}

document.getElementById("save-panic").addEventListener("click", () => {
  panicKey = document.getElementById("panic-key").value;
  panicUrl = document.getElementById("panic-url").value || "https://classroom.google.com";
  localStorage.setItem("panic-key", panicKey);
  localStorage.setItem("panic-url", panicUrl);
});

document.addEventListener("keydown", (e) => {
  if (e.key === panicKey) {
    window.location.href = panicUrl;
  }
});

// Restore cloak on load
const savedTitle = localStorage.getItem("cloak-title");
const savedIcon = localStorage.getItem("cloak-icon");
if (savedTitle) document.title = savedTitle;
if (savedIcon && savedIcon.startsWith("http")) {
  let link = document.querySelector("link[rel~='icon']");
  if (link) link.href = savedIcon;
}
