// Register Ultraviolet service worker
if ("serviceWorker" in navigator) {
  navigator.serviceWorker
    .register("/uv/uv.sw.js", { scope: "/uv/service/", updateViaCache: "none" })
    .then((reg) => {
      console.log("[Nebula] UV Service Worker registered:", reg.scope);
    })
    .catch((err) => {
      console.warn("[Nebula] SW registration failed:", err);
    });
}
